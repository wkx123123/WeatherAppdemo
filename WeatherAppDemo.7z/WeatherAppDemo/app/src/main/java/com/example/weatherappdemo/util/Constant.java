package com.example.weatherappdemo.util;

public class Constant {
    public final static String BASE_URL = "http://guolin.tech/api/china";
    public final static String  WEATHER_BASE_URL = "http://guolin.tech/api/weather?cityid=";
    public final static String KEY = "bc0418b57b2d4918819d3974ac1285d9";
    public final static String OK = "ok";
    public final static String PIC_DAILY_URL = "http://guolin.tech/api/bing_pic";

}
